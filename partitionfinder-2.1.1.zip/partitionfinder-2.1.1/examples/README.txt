README for Examples
___________________


These folders contain an example for each of the three data types PartitionFinder can handle.

The /nucleotide folder demonstrates PartitionFinder
The /aminoacid folder demonstrates PartitionFinderProtein
The /morphology folder demonstrates PartitionFinderMorphology

Instructions on how to run these examples are provided in the manual:

For Mac/Linux Users: Page 7 of the manual
For Windows Users: Page 9 of the manual

Please use the Google group if you have any questions.