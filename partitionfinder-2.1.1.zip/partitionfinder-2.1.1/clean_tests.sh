find . -name analysis -and -d | xargs rm -rf 
find . -name log.txt | xargs rm
